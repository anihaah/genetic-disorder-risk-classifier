# Genetic Disorder Risk Classification System

An educational, end-to-end multiclass ML project using Logistic Regression, Flask, and Streamlit.

> **Important:** This is an experimental educational classifier, not a medical diagnostic tool. Do not use it for patient care.

## 1. Dataset
Download the CSV from [Kaggle: Predict the Genetic Disorders Dataset of Genomes](https://www.kaggle.com/datasets/aibuzz/predict-the-genetic-disorders-datasetof-genomes/data).
Place the CSV in `data/`. The training script can also accept a CSV path with `--data path/to/file.csv`.

The target column is not assumed blindly. The script prints column names and attempts to identify a target column from common names. If it cannot identify it unambiguously, specify `--target "Exact Target Column"`.

## 2. Setup (Windows PowerShell)
```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```

## 3. Train and evaluate
```powershell
python train_model.py --data data/your_dataset.csv
```
If needed:
```powershell
python train_model.py --data data/your_dataset.csv --target "Genetic Disorder"
```
Check `reports/` for metrics and plots and `models/` for the saved pipeline. Never report metrics until this script has successfully run on the real dataset.

## 4. Run Flask API
In terminal 1:
```powershell
python api.py
```
Health check: `http://127.0.0.1:5000/health`
Prediction endpoint: `POST http://127.0.0.1:5000/predict`
Example JSON shape:
```json
{"features": {"feature_name": "value", "another_feature": 1}}
```
Use exact input feature names from the trained dataset. See `reports/model_metadata.json` for those names.

## 5. Run Streamlit frontend
In terminal 2:
```powershell
streamlit run streamlit_app.py
```
Streamlit displays model metrics and available reports. Input controls are generated from the saved model's feature metadata; verify values carefully.

## 6. GitHub
1. Create a public repository on GitHub named `genetic-disorder-risk-classifier`.
2. Do not upload private patient data, `.venv`, secrets, or large raw datasets.
3. Run:
```powershell
git init
git add .
git commit -m "Build genetic disorder classification project"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/genetic-disorder-risk-classifier.git
git push -u origin main
```
Replace `YOUR-USERNAME` with your GitHub username. Ensure `data/` contains only a `.gitkeep` placeholder, not the downloaded dataset.

## Limitations
- Dataset quality and labels may be incomplete or imbalanced.
- Logistic Regression is a baseline; performance may be limited.
- Cross-validation and test metrics are estimates, not clinical validation.
- Class probabilities are model scores, not calibrated clinical risk estimates.
