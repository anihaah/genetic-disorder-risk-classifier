"""Flask prediction API for the trained model."""
from pathlib import Path
import json
import joblib
import pandas as pd
from flask import Flask, jsonify, request

ROOT = Path(__file__).resolve().parent
MODEL_PATH = ROOT / "models" / "genetic_disorder_pipeline.joblib"
METRICS_PATH = ROOT / "reports" / "metrics.json"
META_PATH = ROOT / "reports" / "model_metadata.json"
app = Flask(__name__)

def load_artifacts():
    if not MODEL_PATH.exists() or not META_PATH.exists():
        raise FileNotFoundError("Model not found. Run train_model.py first.")
    model = joblib.load(MODEL_PATH)
    metadata = json.loads(META_PATH.read_text(encoding="utf-8"))
    metrics = json.loads(METRICS_PATH.read_text(encoding="utf-8")) if METRICS_PATH.exists() else {}
    return model, metadata, metrics

@app.get("/health")
def health():
    return jsonify({"status": "ok", "model_available": MODEL_PATH.exists()})

@app.get("/metadata")
def metadata():
    try:
        _, meta, metrics = load_artifacts()
        return jsonify({"features": meta["features"], "classes": meta["class_labels"],
                        "target_column": meta["target_column"], "metrics_summary": {
                            k: metrics.get(k) for k in ["accuracy", "macro_precision", "macro_recall", "macro_f1", "weighted_f1"]
                        }})
    except Exception as exc:
        return jsonify({"error": str(exc)}), 503

@app.post("/predict")
def predict():
    payload = request.get_json(silent=True)
    if not isinstance(payload, dict) or not isinstance(payload.get("features"), dict):
        return jsonify({"error": "Send JSON in the form {'features': {'feature_name': 'value'}}"}), 400
    try:
        model, meta, _ = load_artifacts()
        missing = [f for f in meta["features"] if f not in payload["features"]]
        if missing:
            return jsonify({"error": "Missing required feature(s)", "missing_features": missing}), 400
        row = {f: payload["features"][f] for f in meta["features"]}
        frame = pd.DataFrame([row], columns=meta["features"])
        prediction = str(model.predict(frame)[0])
        result = {"prediction": prediction,
                  "disclaimer": "Experimental educational output only; not a medical diagnosis."}
        if hasattr(model, "predict_proba"):
            probs = model.predict_proba(frame)[0]
            result["class_probabilities"] = {
                str(cls): float(prob) for cls, prob in zip(model.classes_, probs)
            }
        return jsonify(result)
    except FileNotFoundError as exc:
        return jsonify({"error": str(exc)}), 503
    except Exception as exc:
        return jsonify({"error": "Prediction failed", "details": str(exc)}), 400

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
