"""Streamlit interface for the genetic disorder classification project."""
from pathlib import Path
import json
import joblib
import pandas as pd
import streamlit as st

ROOT = Path(__file__).resolve().parent
MODEL_PATH = ROOT / "models" / "genetic_disorder_pipeline.joblib"
META_PATH = ROOT / "reports" / "model_metadata.json"
METRICS_PATH = ROOT / "reports" / "metrics.json"
REPORTS = ROOT / "reports"

st.set_page_config(page_title="Genetic Disorder Classifier", page_icon="🧬", layout="wide")
st.title("🧬 Genetic Disorder Risk Classification")
st.warning("Educational prototype only. This tool is not a medical diagnostic system and must not guide clinical decisions.")

if not MODEL_PATH.exists() or not META_PATH.exists():
    st.error("The model has not been trained yet. Follow the README: download the dataset, then run train_model.py.")
    st.stop()

@st.cache_resource
def load_model():
    return joblib.load(MODEL_PATH)
model = load_model()
meta = json.loads(META_PATH.read_text(encoding="utf-8"))
metrics = json.loads(METRICS_PATH.read_text(encoding="utf-8")) if METRICS_PATH.exists() else {}

st.subheader("Model performance")
cols = st.columns(4)
for col, label, key in zip(cols, ["Accuracy", "Macro precision", "Macro recall", "Macro F1-score"],
                           ["accuracy", "macro_precision", "macro_recall", "macro_f1"]):
    value = metrics.get(key)
    col.metric(label, f"{value:.3f}" if isinstance(value, (int, float)) else "Not available")
st.caption("Metrics are calculated on a held-out test split. They are not evidence of clinical validity.")

tab_predict, tab_eval, tab_about = st.tabs(["Patient attributes", "Evaluation & charts", "Limitations"])
with tab_predict:
    st.write("Enter values for the dataset features. Values should match the training dataset's format.")
    with st.form("prediction_form"):
        values = {}
        c1, c2 = st.columns(2)
        for i, feature in enumerate(meta["features"]):
            target_col = c1 if i % 2 == 0 else c2
            if feature in meta.get("numeric_features", []):
                values[feature] = target_col.number_input(feature, value=0.0, format="%.4f", help="Enter a numeric value. Use 0 only if appropriate for this feature.")
            else:
                values[feature] = target_col.text_input(feature, value="", help="Enter the category/value as represented in the dataset. Leave blank only if missing values were represented during training.")
        submitted = st.form_submit_button("Predict category", type="primary")
    if submitted:
        try:
            row = pd.DataFrame([{k: (None if v == "" else v) for k, v in values.items()}], columns=meta["features"])
            prediction = str(model.predict(row)[0])
            st.success(f"Predicted dataset category: **{prediction}**")
            if hasattr(model, "predict_proba"):
                probabilities = model.predict_proba(row)[0]
                prob_df = pd.DataFrame({"Category": model.classes_.astype(str), "Model score": probabilities}).sort_values("Model score", ascending=False)
                st.subheader("Model probability scores")
                st.bar_chart(prob_df.set_index("Category"))
                st.caption("These are model probability outputs, not clinically calibrated genetic risk estimates.")
        except Exception as exc:
            st.error(f"Prediction failed: {exc}")

with tab_eval:
    st.subheader("Confusion matrix")
    cm_path = REPORTS / "confusion_matrix.png"
    if cm_path.exists():
        st.image(str(cm_path), use_container_width=True)
    else:
        st.info("Train the model to generate the confusion matrix.")
    for name, title in [("class_distribution.png", "Target class distribution"),
                        ("missing_values.png", "Missing values by column")]:
        path = REPORTS / name
        if path.exists():
            st.subheader(title)
            st.image(str(path), use_container_width=True)
    report_path = REPORTS / "classification_report.csv"
    if report_path.exists():
        st.subheader("Per-class precision, recall and F1-score")
        st.dataframe(pd.read_csv(report_path, index_col=0), use_container_width=True)

with tab_about:
    st.markdown("""
    - **Accuracy** measures the fraction of correct predictions overall.
    - **Precision** measures how often predictions for a class are correct.
    - **Recall** measures how many actual examples of a class are found.
    - **F1-score** balances precision and recall.
    - **Macro-F1** gives each class equal weight, making it useful when classes are imbalanced.

    In a health-related research setting, missed categories may matter, so per-class recall deserves careful attention. Precision also matters because false alarms can cause unnecessary concern. Metric priorities must be defined with domain experts and validated data.
    """)
