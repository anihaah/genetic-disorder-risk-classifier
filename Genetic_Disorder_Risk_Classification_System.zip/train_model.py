"""Train and evaluate an educational multiclass Logistic Regression pipeline."""
from __future__ import annotations
import argparse, json, os, re, warnings
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.compose import ColumnTransformer
from sklearn.feature_selection import SelectPercentile, f_classif
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, classification_report, confusion_matrix,
                             ConfusionMatrixDisplay, f1_score, precision_score,
                             recall_score)
from sklearn.model_selection import train_test_split, StratifiedKFold, cross_val_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.base import clone
import joblib

ROOT = Path(__file__).resolve().parent
MODEL_PATH = ROOT / "models" / "genetic_disorder_pipeline.joblib"
REPORTS = ROOT / "reports"
COMMON_TARGETS = ["Genetic Disorder", "genetic_disorder", "Disorder", "disorder",
                  "target", "Target", "Class", "class", "Genetic_Disorder"]

def clean_frame(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df.columns = [str(c).strip() for c in df.columns]
    df = df.replace(r"^\s*$", np.nan, regex=True)
    df = df.replace(["?", "NA", "N/A", "na", "null", "None", "unknown", "Unknown"], np.nan)
    # Common Kaggle export artifact: unnamed index columns
    df = df.loc[:, ~df.columns.str.match(r"^Unnamed")]
    return df

def infer_target(columns, requested=None):
    if requested:
        if requested not in columns:
            raise ValueError(f"Target '{requested}' not found. Available columns: {list(columns)}")
        return requested
    for candidate in COMMON_TARGETS:
        if candidate in columns:
            return candidate
    matches = [c for c in columns if "genetic disorder" in c.lower() or c.lower() == "disorder"]
    if len(matches) == 1:
        return matches[0]
    raise ValueError("Could not safely infer the target column. Re-run with --target followed by the exact target column name.")

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", required=True, help="Path to the Kaggle CSV")
    parser.add_argument("--target", default=None, help="Exact target column name if not auto-detected")
    args = parser.parse_args()
    data_path = Path(args.data)
    if not data_path.exists():
        raise FileNotFoundError(f"CSV not found: {data_path}. Download the Kaggle dataset and pass its path.")
    df = clean_frame(pd.read_csv(data_path))
    print("\n=== Dataset inspection ===")
    print("Shape:", df.shape)
    print("Columns:", list(df.columns))
    print("\nMissing values (top 20):\n", df.isna().sum().sort_values(ascending=False).head(20))
    target = infer_target(df.columns, args.target)
    df = df.dropna(subset=[target]).copy()
    # Drop labels that occur only once: they cannot support stratified holdout reliably.
    counts = df[target].astype(str).value_counts()
    rare = counts[counts < 2].index
    if len(rare):
        warnings.warn(f"Dropping {len(rare)} row(s) whose target class occurs only once; document this limitation.")
        df = df[~df[target].astype(str).isin(rare)].copy()
    if df[target].nunique() < 2:
        raise ValueError("Need at least two target classes to train a classifier.")
    y = df[target].astype(str)
    X = df.drop(columns=[target])
    # Remove likely identifiers to reduce memorization. User can review this list.
    id_like = [c for c in X.columns if c.lower().strip() in {"id", "patient id", "patient_id", "sample id", "sample_id"}]
    if id_like:
        X = X.drop(columns=id_like)
        print("Dropped identifier columns:", id_like)
    # Remove columns entirely missing and constant columns.
    empty = [c for c in X.columns if X[c].isna().all()]
    constant = [c for c in X.columns if X[c].nunique(dropna=True) <= 1]
    drop_cols = sorted(set(empty + constant))
    if drop_cols:
        X = X.drop(columns=drop_cols)
        print("Dropped empty/constant columns:", drop_cols)
    if X.shape[1] == 0:
        raise ValueError("No usable feature columns remain.")
    # Infer numeric vs categorical using pandas dtypes.
    numeric_cols = X.select_dtypes(include=["number"]).columns.tolist()
    categorical_cols = [c for c in X.columns if c not in numeric_cols]
    numeric_pipe = Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler())
    ])
    categorical_pipe = Pipeline([
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore"))
    ])
    transformers = []
    if numeric_cols: transformers.append(("numeric", numeric_pipe, numeric_cols))
    if categorical_cols: transformers.append(("categorical", categorical_pipe, categorical_cols))
    preprocessor = ColumnTransformer(transformers=transformers, remainder="drop")
    # Feature selection is inside the pipeline to prevent leakage.
    model = Pipeline([
        ("preprocess", preprocessor),
        ("select", SelectPercentile(score_func=f_classif, percentile=80)),
        ("classifier", LogisticRegression(max_iter=2500, class_weight="balanced"))
    ])
    class_counts = y.value_counts()
    min_class_count = int(class_counts.min())
    if min_class_count < 2:
        raise ValueError("At least two examples per class are required for stratified train/test splitting.")
    test_fraction = max(0.2, len(class_counts) / len(y))
    test_fraction = min(test_fraction, 0.4)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_fraction, random_state=42, stratify=y
    )
    model.fit(X_train, y_train)
    pred = model.predict(X_test)
    labels = sorted(y.unique().tolist())
    metrics = {
        "target_column": target,
        "dataset_rows_after_cleaning": int(len(df)),
        "feature_count_before_encoding": int(X.shape[1]),
        "class_labels": labels,
        "accuracy": float(accuracy_score(y_test, pred)),
        "macro_precision": float(precision_score(y_test, pred, average="macro", zero_division=0)),
        "macro_recall": float(recall_score(y_test, pred, average="macro", zero_division=0)),
        "macro_f1": float(f1_score(y_test, pred, average="macro", zero_division=0)),
        "weighted_f1": float(f1_score(y_test, pred, average="weighted", zero_division=0)),
        "classification_report": classification_report(y_test, pred, output_dict=True, zero_division=0),
        "confusion_matrix": confusion_matrix(y_test, pred, labels=labels).tolist(),
        "features": X.columns.tolist(),
        "numeric_features": numeric_cols,
        "categorical_features": categorical_cols,
        "dropped_columns": drop_cols + id_like,
        "note": "Educational model only; not validated for clinical use."
    }
    # Cross-validation uses training data only, avoiding test-set leakage.
    cv_splits = min(5, int(y_train.value_counts().min()))
    if cv_splits >= 2:
        cv = StratifiedKFold(n_splits=cv_splits, shuffle=True, random_state=42)
        cv_scores = cross_val_score(clone(model), X_train, y_train, cv=cv, scoring="f1_macro", n_jobs=None)
        metrics["cv_macro_f1_scores"] = [float(v) for v in cv_scores]
        metrics["cv_macro_f1_mean"] = float(np.mean(cv_scores))
        metrics["cv_macro_f1_std"] = float(np.std(cv_scores))
    else:
        metrics["cv_note"] = "Cross-validation skipped because at least two training samples per class were unavailable."
    REPORTS.mkdir(exist_ok=True); (ROOT / "models").mkdir(exist_ok=True)
    joblib.dump(model, MODEL_PATH)
    with open(REPORTS / "metrics.json", "w", encoding="utf-8") as f:
        json.dump(metrics, f, indent=2, default=str)
    metadata = {"target_column": target, "features": X.columns.tolist(),
                "numeric_features": numeric_cols, "categorical_features": categorical_cols,
                "class_labels": labels, "model_path": str(MODEL_PATH.name)}
    with open(REPORTS / "model_metadata.json", "w", encoding="utf-8") as f:
        json.dump(metadata, f, indent=2)
    # EDA: class distribution
    plt.figure(figsize=(10, 5))
    y.value_counts().plot(kind="bar")
    plt.title("Target Class Distribution"); plt.xlabel(target); plt.ylabel("Rows")
    plt.xticks(rotation=35, ha="right"); plt.tight_layout()
    plt.savefig(REPORTS / "class_distribution.png", dpi=160); plt.close()
    plt.figure(figsize=(10, 5))
    df.isna().sum().sort_values(ascending=False).head(20).plot(kind="bar")
    plt.title("Missing Values by Column (Top 20)"); plt.ylabel("Missing count")
    plt.xticks(rotation=45, ha="right"); plt.tight_layout()
    plt.savefig(REPORTS / "missing_values.png", dpi=160); plt.close()
    plt.figure(figsize=(8, 6))
    ConfusionMatrixDisplay.from_predictions(y_test, pred, labels=labels, xticks_rotation=45, cmap="Blues")
    plt.title("Confusion Matrix — Test Set"); plt.tight_layout()
    plt.savefig(REPORTS / "confusion_matrix.png", dpi=160); plt.close()
    report_df = pd.DataFrame(metrics["classification_report"]).T
    report_df.to_csv(REPORTS / "classification_report.csv")
    print("\n=== TEST SET PERFORMANCE (real dataset run) ===")
    print(f"Accuracy: {metrics['accuracy']:.3f}")
    print(f"Macro precision: {metrics['macro_precision']:.3f}")
    print(f"Macro recall: {metrics['macro_recall']:.3f}")
    print(f"Macro F1: {metrics['macro_f1']:.3f}")
    if "cv_macro_f1_mean" in metrics:
        print(f"CV macro-F1: {metrics['cv_macro_f1_mean']:.3f} ± {metrics['cv_macro_f1_std']:.3f}")
    print("\nClassification report:\n", classification_report(y_test, pred, zero_division=0))
    print(f"\nSaved model: {MODEL_PATH}")
    print(f"Saved reports and plots in: {REPORTS}")
    print("Reminder: these are research/educational estimates, not clinical validation.")

if __name__ == "__main__":
    main()
